a = 28
b = 1.5
c = "Hello!"
d = True
e = None
