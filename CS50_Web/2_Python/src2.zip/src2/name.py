name = input("Name: ")
print(f"Hello, {name}")
