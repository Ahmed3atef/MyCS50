from time import sleep

for i in range(0000, 10000):
    print(f"Checking {i:04}...")
    sleep(.1)
