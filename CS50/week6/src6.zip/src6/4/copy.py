# Capitalizes a copy of a string

from cs50 import get_string

# Get a string
s = get_string("s: ")

# Copy string
t = s

# Capitalize copy
t = t.capitalize()

# Print strings
print(f"s: {s}")
print(f"t: {t}")
