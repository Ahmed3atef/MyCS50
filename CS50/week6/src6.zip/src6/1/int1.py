# input, int, and print

age = int(input("What's your age?\n"))
print(f"You are at least {age * 365} days old.")
