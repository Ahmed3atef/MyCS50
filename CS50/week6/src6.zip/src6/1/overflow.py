# Integer non-overflow

from time import sleep

# Iteratively double i
i = 1
while True:
    print(i)
    sleep(1)
    i *= 2
