# Abstraction


def main():
    for i in range(3):
        cough()


# Cough once
def cough():
    print("cough")


main()
