# Averages three numbers using a list with append

# Scores
scores = []
scores.append(72)
scores.append(73)
scores.append(33)

# Print average
print(f"Average: {sum(scores) / len(scores)}")
